﻿namespace GSM04500Back
{
        public class GSM04500DBParameter
        {
            public string CCOMPANY_ID { get; set; }
            public string CUSER_ID { get; set; }
            public string CPROPERTY_ID { get; set; }
            public string CJRNGRP_TYPE { get; set; }
            public string LANGUAGE  { get; set; }
    }
}