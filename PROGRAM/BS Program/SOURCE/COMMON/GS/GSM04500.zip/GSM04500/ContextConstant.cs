﻿namespace GSM04500Common
{
    public class ContextConstant
    {
        public const string CJRNGRP_TYPE = "CJRNGRP_TYPE";
        public const string CPROPERTY_ID = "CPROPERTY_ID";
        public const string CJOURNAL_GRP_CODE = "CJOURNAL_GRP_CODE";
        public const string CGOA_CODE = "CGOA_CODE";
        public const string COVERWRITE = "COVERWRITE";

    }


}
