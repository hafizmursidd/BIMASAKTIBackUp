﻿Public Class R_SecurityPolicyTokenDTO
    Public Property CTOKEN As String
    Public Property CTOKEN_ID As String
End Class
