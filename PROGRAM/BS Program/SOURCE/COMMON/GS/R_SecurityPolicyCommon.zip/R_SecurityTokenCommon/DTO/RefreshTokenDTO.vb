Public Class RefreshTokenDTO
    Public Property CREFRESH_TOKEN As String
    Public Property DREFRESH_TOKEN_UTC_CREATED As DateTime
    Public Property DREFRESH_TOKEN_UTC_EXPIRES As DateTime
    Public Property CTOKEN_IP_ADDRESS As String
End Class
