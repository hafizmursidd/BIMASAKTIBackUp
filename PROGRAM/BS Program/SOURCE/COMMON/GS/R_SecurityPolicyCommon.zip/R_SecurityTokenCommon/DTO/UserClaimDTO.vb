﻿Public Class UserClaimDTO
    Public Property CCOMPANY_ID As String
    Public Property CUSER_ID As String
    Public Property CUSER_ROLE As String
End Class
